External USB camera
